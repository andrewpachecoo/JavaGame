/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist240_game;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

/**
 *
 * @author aqh5621
 */
public class Inst extends JPanel{
    private tennis.TennisFrame tennisgame;
    private tennis.TennisGame tennisgamewin;
    
    private ClickMe.GamePanel clickMe;
    private ClickMe.ClickMeMainFrame clickMeMF;
    
    private rps.ControlPanel rpsgame;
    private rps.MainFrame rpsframe;
    
    JLabel jl2;
    
    ImageIcon inst11 = new ImageIcon("images/instructions.png");
    
    
    
    public Inst()
    {
        super();
        setLayout(null);
        
        tennisgame = new tennis.TennisFrame();
        tennisgamewin = new tennis.TennisGame(tennisgame);
        
        clickMeMF = new ClickMe.ClickMeMainFrame();
        clickMe = new ClickMe.GamePanel(clickMeMF);
        
        rpsframe = new rps.MainFrame();
        rpsgame = new rps.ControlPanel(rpsframe);
  
        jl2 = new JLabel();
        add(jl2);
        jl2.setIcon(inst11);
        jl2.setLocation(50, 0);
        jl2.setSize(1000, 800);
        
        
    
    }
    
}
