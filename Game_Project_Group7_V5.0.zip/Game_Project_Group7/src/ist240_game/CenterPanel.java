/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ist240_game;

/**
 *
 * @author User
 */
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

public class CenterPanel extends JPanel
{

    private BufferedImage image;
    JLabel jl1, jl2, jl3;

    public CenterPanel()
    {
        super();
        setLayout(null);
        try {                
          image = ImageIO.read(new File("images/ISTsample.jpg"));
       } catch (IOException ex) {
            
       }
        jl1 = new JLabel("Group 7");
        add(jl1);
        jl1.setForeground(Color.BLUE);
        jl1.setFont(new Font("Calibri", Font.PLAIN, 30));
        jl1.setLocation(884, 600);
        jl1.setSize(900, 100);
        
        jl2 = new JLabel("AungNay, Hojin, Bennet, Andrew");
        add(jl2);
        jl2.setForeground(Color.WHITE);
        jl2.setFont(new Font("Calibri", Font.PLAIN, 24));
        jl2.setLocation(660, 630);
        jl2.setSize(900, 100);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 100, 50, this);         
    }

    }