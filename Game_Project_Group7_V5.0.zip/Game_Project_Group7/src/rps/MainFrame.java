package rps;
import java.awt.*;
import javax.swing.*;


public class MainFrame extends JFrame
{
    ControlPanel game;
    
    public MainFrame()
    {
        super();
        
        game = new ControlPanel(this);
        add(game, "Center");
        
        
    }

}
