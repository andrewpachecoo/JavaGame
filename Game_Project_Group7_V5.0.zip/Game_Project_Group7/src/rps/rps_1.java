
package rps;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * This is rock paper scissor game
 */
public class rps_1 extends JPanel {
    JButton jb1, jb2, jb3, jb4, jb5, jb6, compchoice;
    String result;
    TopPanel Top;
    
    public rps_1(TopPanel Top){
        super();
        GridLayout gridlayout = new GridLayout(3, 2);
        setLayout(gridlayout);
        jb1 = new JButton();
        jb2 = new JButton();
        jb3 = new JButton();
        jb4 = new JButton();
        jb5 = new JButton();
        jb6 = new JButton();
        ImageIcon rock = new ImageIcon("images/rock.jpg");
        ImageIcon scs = new ImageIcon("images/scs.jpg");
        ImageIcon pap = new ImageIcon("images/paper.jpg");
        
        //jb 123 is user jb456 is computer
        jb1.setIcon(rock);
        jb2.setIcon(scs);
        jb3.setIcon(pap);
        jb4.setIcon(rock);
        jb5.setIcon(scs);
        jb6.setIcon(pap);
        add(jb1);
        add(jb4);
        add(jb2);
        add(jb5);
        add(jb3);
        add(jb6);

        }
    
    JButton computerchoice(){
        int number = (int) (Math.random() * 3) + 1;
        if (number == 1){
            compchoice = jb4;
            compchoice.setBackground(Color.BLUE);
            compchoice.setOpaque(true);
        }
        if (number == 2){
            compchoice = jb5;
            compchoice.setBackground(Color.BLUE);
            compchoice.setOpaque(true);
        }
        if (number == 3){
            compchoice = jb6;
            compchoice.setBackground(Color.BLUE);
            compchoice.setOpaque(true);
        }
        return compchoice;
    }
    
    //whowins method returns who won the game
    public String whowins(Object uchoice, JButton choice){
        if(uchoice == jb1){
             if(choice == jb4)
                 result = "Draw";
             if(choice == jb5)
                 result = "Win";
             if(choice == jb6)
                 result = "Lose";
        }
        
        if(uchoice == jb2){
            if(choice == jb4)
                result = "Lose";
            if(choice == jb5)
                result = "Draw";
            if(choice == jb6)
                result = "Win";
             }
        
        if(uchoice == jb3){
            if(choice == jb4)
                result = "Win";
            if(choice == jb5)
               result = "Lose";
            if(choice == jb6)
               result = "Draw";
            }
        
        //System.out.println(result);
        return result;
    }
    

    public void returnBGcolor(TopPanel rpx)
    {
        Top = rpx;
        jb1.setBackground(null);
        jb1.setOpaque(true);
        jb2.setBackground(null);
        jb2.setOpaque(true);
        jb3.setBackground(null);
        jb3.setOpaque(true);
        jb4.setBackground(null);
        jb4.setOpaque(true);
        jb5.setBackground(null);
        jb5.setOpaque(true);
        jb6.setBackground(null);
        jb6.setOpaque(true);
        rpx.nextbutton.setBackground(null);
        jb6.setOpaque(true);
    }
        

}

