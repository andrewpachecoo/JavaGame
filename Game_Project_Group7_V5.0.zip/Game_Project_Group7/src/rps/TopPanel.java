
package rps;
import java.awt.*;
import javax.swing.*;
//Show instruct and score recieves actionlistener inside rps_1 shows who wins and tracks score
//Stops when certain score hits. For the game should we make it time challenge?
public class TopPanel extends JPanel {
    int Uscore, Cscore;
    String Udisplay, Cdisplay;
    private JLabel jl1, jl2, jl3, jl4, jl5, jl6;
    JButton nextbutton;
    rps_1 game;
    
    TopPanel(rps_1 rpx){
        super();
        setBackground(Color.gray);
        game = rpx;
        Uscore = 0;
        Udisplay = Integer.toString(Uscore);
        Cscore = 0;
        Cdisplay = Integer.toString(Cscore);
        this.setBackground(Color.WHITE);
        FlowLayout flow = new FlowLayout();
        setLayout(flow); 
        jl1 = new JLabel("Result: ");
        jl2 = new JLabel(" / ");
        jl3 = new JLabel("Your Score: ");
        jl4 = new JLabel(Udisplay + " / ");
        jl5 = new JLabel("Computer Score: ");
        jl6 = new JLabel(Cdisplay +"  / First to 3 Wins     ");
        nextbutton = new JButton("Press to Start Battle!");
        nextbutton.setBackground(Color.GREEN);
        nextbutton.setOpaque(true);
        add(jl1);
        add(jl2);
        add(jl3);
        add(jl4);
        add(jl5);
        add(jl6);
        add(nextbutton);    
    }
    
    public void updatescore(String result){
        if(result == "Draw"){
            jl2.setText(result + " / ");
            nextbutton.setBackground(Color.GREEN);
            nextbutton.setOpaque(true);
        }
        if(result == "Win"){
            Uscore += 1;
            Udisplay = Integer.toString(Uscore);
            //System.out.println(Uscore);
            jl2.setText(result + " / ");
            jl4.setText(Udisplay);
            nextbutton.setBackground(Color.GREEN);
            nextbutton.setOpaque(true);
        }
        if(result == "Lose"){
            Cscore += 1;
            Cdisplay = Integer.toString(Cscore);
            //System.out.println(Cscore);
            jl2.setText(result + " / ");
            jl6.setText(Cdisplay);
            nextbutton.setBackground(Color.GREEN);
            nextbutton.setOpaque(true);
        }
        
    }
        
}
