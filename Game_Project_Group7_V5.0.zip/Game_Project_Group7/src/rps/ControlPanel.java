
package rps;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JOptionPane;

public class ControlPanel extends JPanel implements ActionListener{
    rps_1 Rpsgame;
    TopPanel Top;
    
    MainFrame mf11;
    
    private boolean ActionLcheck; //prevent Topnext add multiple actionlisteners

    public ControlPanel(MainFrame mainf){
        super();
        
        this.mf11 = mainf;
        
        BorderLayout border = new BorderLayout();
        setLayout(border);
        Rpsgame = new rps_1(Top);//sequence
        Top = new TopPanel(Rpsgame);
        Top.nextbutton.addActionListener(this);
        add(Rpsgame, "Center");
        add(Top, "North");
        ActionLcheck = false;
    }

    public void gameOver(){
        if(Top.Uscore == 3){
            JOptionPane.showMessageDialog(this, "You Won by: " + (Top.Uscore - Top.Cscore),
                    "Go Now. Don't look back", JOptionPane.YES_NO_OPTION);
            //System.exit(0);
        }
        if(Top.Cscore == 3){
            JOptionPane.showMessageDialog(this, "You Lost by: " + (Top.Cscore - Top.Uscore),
                    "Try again. If You Dare", JOptionPane.YES_NO_OPTION);
            //System.exit(0);
        }
    }
    
    
    @Override
    public void actionPerformed(ActionEvent event) {
        Object obj = event.getSource();
        //System.out.println(obj);
        if (obj == Top.nextbutton){
            Top.nextbutton.setText("Press for Next Battle!");
            Rpsgame.returnBGcolor(Top);
                if(ActionLcheck == false){
                Rpsgame.jb1.addActionListener(this);
                Rpsgame.jb2.addActionListener(this);
                Rpsgame.jb3.addActionListener(this);
                ActionLcheck = true;
                }
        }
    
        if (obj == Rpsgame.jb1){            
            Rpsgame.jb1.setBackground(Color.RED);
            Rpsgame.jb1.setOpaque(true);
            JButton comp = Rpsgame.computerchoice();
            String text = Rpsgame.whowins(obj, comp);
            Top.updatescore(text);
            Rpsgame.jb1.removeActionListener(this);
            Rpsgame.jb2.removeActionListener(this);
            Rpsgame.jb3.removeActionListener(this);
            ActionLcheck = false;
            gameOver();
        }
        if (obj == Rpsgame.jb2){
            Rpsgame.jb2.setBackground(Color.RED); 
            Rpsgame.jb2.setOpaque(true);
            JButton comp = Rpsgame.computerchoice();
            String text = Rpsgame.whowins(obj, comp);
            Top.updatescore(text);
            Rpsgame.jb1.removeActionListener(this);
            Rpsgame.jb2.removeActionListener(this);
            Rpsgame.jb3.removeActionListener(this);
            ActionLcheck = false;
            gameOver();
        }
        if (obj == Rpsgame.jb3){
            Rpsgame.jb3.setBackground(Color.RED);
            Rpsgame.jb3.setOpaque(true);
            JButton comp = Rpsgame.computerchoice();
            String text = Rpsgame.whowins(obj, comp);
            Top.updatescore(text);
            Rpsgame.jb1.removeActionListener(this);
            Rpsgame.jb2.removeActionListener(this);
            Rpsgame.jb3.removeActionListener(this);
            ActionLcheck = false;
            gameOver();
        }
    }

}
